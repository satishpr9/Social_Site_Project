from django.db import models
from django.urls import reverse
# Create your models here.
from django.db.models.signals import pre_save

from django.utils.text import slugify


from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver
# Create your models here.
class Post(models.Model):
    user=models.ForeignKey(User,on_delete=models.CASCADE)
    caption=models.CharField(max_length=10000)
    img=models.ImageField(upload_to='')
    date=models.DateTimeField(auto_now_add=True)
    slug=models.CharField(max_length=500)
    

    def __str__(self):
        return str(self.caption)
    @property
    def get_absolute_url(self):
       return reverse("post_detail", kwargs={"slug": self.slug})     



class Profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    date=models.DateTimeField(auto_now_add=True, blank=True)
    Bio=models.CharField(max_length=500,blank=True)
    image=models.ImageField(upload_to='', default='default.jpg',blank = True, height_field=None,width_field=None)
    connection = models.CharField(max_length = 100, blank=True)
    follower = models.IntegerField(default=0)
    following = models.IntegerField(default=0)
 

    def __str__(self):
        return str(self.user)

    # def create_user_profile(sender, instance, created, **kwargs):
    #     if created:
    #         Profile.objects.create(user=instance)

    # post_save.connect(create_user_profile, sender=User)


class Like(models.Model):
    user=models.ManyToManyField(User,related_name="linkingUser")
    post=models.OneToOneField(Post,on_delete=models.CASCADE)
    likes=models.IntegerField(default=0)

    @classmethod
    def like(cls,post,liking_user):
        obj, create = cls.objects.get_or_create(post=post)
        obj.user.add(liking_user)

    @classmethod
    def dislike(cls,post,disliking_user):
        obj, create = cls.objects.get_or_create(post=post)
        obj.user.remove(disliking_user)    

    def __str__(self):
        return str(self.post)    


class Comment(models.Model):
   
    user_id=models.ForeignKey(User,on_delete=models.CASCADE)
    slug=models.CharField(max_length=1000,null=True, blank=True)
    msg=models.TextField('comment')


   
        
    def __str__(self):
        return 'Comment {} by {}'.format( self.msg,self.user_id)



# @receiver(pre_save, sender=Post)
# def pre_save_slug(sender,  **kwargs):
#     print(kwargs)
#     slug=slugify(kwargs['instance'].title)
#     kwargs['instance'].slug=slug


class Following(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    followed=models.ManyToManyField(User, related_name="followed")

    @classmethod

    def follow(cls,user,another_account):
        obj, create=cls.objects.get_or_create(user=user)
        obj.followed.add(another_account)
        print("Followed")

    @classmethod
    def unfollow(cls,user,another_account):
        obj, create=cls.objects.get_or_create(user=user)
        obj.followed.remove(another_account)
        print("UnFollow")
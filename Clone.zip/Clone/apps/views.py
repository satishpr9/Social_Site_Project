from django.shortcuts import render,redirect,get_object_or_404,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login,logout
from django.contrib import messages
from .models import Post,Profile,Like,Comment,Following
from django.contrib.auth.decorators import login_required
from .forms import *
from django.http import JsonResponse
from django.db.models import  Q
import json

# Create your views here.


def index(request):
    post=Post.objects.all().order_by("-id")
    posts=Profile.objects.all()
    comment=Comment.objects.all().order_by("-id")
    liked_=[i for i in post if Like.objects.filter(post=i,user=request.user)]
    query=request.GET.get('q')
    if query:
        post=Profile.objects.filter(
            Q(user__username__icontains=query )| Q(Bio__icontains=query)
        )

    context={
        'post':post,
        'posts':posts,
        'liked_post':liked_,
        'comment':comment,
    }

    return render(request,"index.html",context)





def post(request):
    if request.method=="POST":
        image=request.FILES['image']
        captions=request.POST.get('captions','')
        
        user_=request.user


        post_object=Post(user=user_,caption=captions,img=image)
        post_object.save()
        messages.success(request,'Successfully Submit')
        return redirect("/index")
    else:
        messages.error(request,"something went wrong")
        return redirect("/index")    





def signup(request):
    if request.method=="POST":
        username=request.POST.get('username','')
        name=request.POST.get('name','')
        mail=request.POST.get('email','')
        password=request.POST.get('password','')
        conf_pass=request.POST.get('confpass','')
        
        userCheker=User.objects.filter(username=username)

        if userCheker:
            messages.error(request,"already have an account")
            return redirect("/")


        print(username)
        print(name)
        print(mail)
        print(password)
        print(conf_pass)

        if password==conf_pass:
            user_obj=User.objects.create_user(first_name=name,username=username,email=mail,password=password)
            user_obj.save()
            Profile.objects.create(user=user_obj)
            messages.success(request,'SuccessFully Register')
            

    return render(request,'user/signup.html')


def user_login(request):
    if request.method=='POST':
        user_name=request.POST.get('username','')
        pass_word=request.POST.get('password','')

        user=authenticate(username=user_name,password=pass_word)

        if user is not None:
            login(request,user)
            return redirect('/index')
        else:
            messages.error(request,"invalid user and password")
            return redirect("/")
    return redirect("/")


def user_profile(request, username):
    user = User.objects.filter(username=username)
    if user:
        user = user[0]
        profile = Profile.objects.get(user=user)
        post = getPost(user)
        Bio = profile.Bio
        conn = profile.connection
        follower, following = profile.follower, profile.following
        user_img = profile.image
        is_following=Following.objects.filter(user=request.user, followed=user)
        data = {
            'user_obj':user,
            'Bio':Bio,
            'conn':conn,
            'follower':follower,
            'following':following,
            'userImg':user_img,
            'posts':post,
            'connection':is_following,
        }
    else: 
        return HttpResponse('no such user')

    return render(request, 'user/profile.html', data)


def getPost(user):
    post_obj = Post.objects.filter(user=user)
    imgList= [post_obj[i:i+3] for i in range(0, len(post_obj), 3)]
    return imgList


def user_logout(request):
    logout(request)
    messages.success(request,"successfully logout")
    return redirect("/")



def likePost(request):
    post_id=request.GET.get("likeId", "")
    print(post_id)
    post=Post.objects.get(pk=post_id)
    user=request.user# post=Post.objects.get(pk=id)
   
    
    
    like=Like.objects.filter(post=post,user=user)

    liked=False

    if like:
       Like.dislike(post,user)
    else:
        liked=True
        Like.like(post,user)

    resp={
        'liked':liked
    }       

    response=json.dumps(resp)
    return HttpResponse(response, content_type="application/json")

def delPost(request, postId):
    post_=Post.objects.filter(pk=postId)
    img_path=post_[0].img.url  #image location system
    post_.delete()
    messages.success(request,"successfully Delete")

    return redirect("/index")



def edit_profile(request):
    if request.method=="POST":
        user_form=UserEditForm(data=request.POST or None, instance=request.user)
        profile_form=ProfileEditForm(data=request.POST or None, instance=request.user.profile, files=request.FILES)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()

    else:
        user_form=UserEditForm(instance=request.user) 
        profile_form=ProfileEditForm(instance=request.user.profile)    
    context ={
        'user_form':user_form,
        'profile_form':profile_form,
    }       

    return render(request,'user/editprofile.html', context)

def follow(request, username):
    main_user=request.user
    to_follow=User.objects.get(username=username)

    #if already following
    following=Following.objects.filter(user=main_user, followed=to_follow)
    is_following=True if following else False

    if is_following:
        #unfollow the user
        Following.unfollow(main_user,to_follow)
        is_following=False
    else:
        Following.follow(main_user,to_follow)
        is_following=True

    resp={
        "following":is_following,
    }

    response=json.dumps(resp)

    return HttpResponse(response,content_type="application/json")
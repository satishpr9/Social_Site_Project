from django.urls import path
from apps import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns=[
    path('',views.signup, name="signup"),
    path('user_login',views.user_login, name="user_login"),
    path('index',views.index,name="index"),
    path('user_logout',views.user_logout,name="user_logout"),
    path('post',views.post,name="post"),
    path("like",views.likePost, name="likepost"),
    path("<int:postId>",views.delPost, name="delPost"),
    path('<str:username>',views.user_profile, name="user_profile"),
    path('accounts/edit_profile',views.edit_profile, name="edit_profile"),
    path('user/follow/<str:username>',views.follow, name="follow")
   
    
  
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)